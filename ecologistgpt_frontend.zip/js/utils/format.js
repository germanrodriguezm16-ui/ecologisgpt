export function fmt(n){ return Number(n||0).toLocaleString('es-CO',{maximumFractionDigits:2}); }
